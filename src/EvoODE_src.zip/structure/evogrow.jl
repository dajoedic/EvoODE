# src/structure/evogrow.jl

using Random
using Printf

"""
EvoGrow structure search strategy.

- pop_size: population size
- n_levels: number of growth levels
- children_per_parent: number of children sampled per parent per level
- max_terms_per_eq: maximum number of active terms per equation
- λ: complexity penalty (objective = loss + λ * n_params)

Version note:
- v1: flat growth over all terms
- v2: staged growth over predefined basis groups
- v2.1: stage-aware child generation
"""
Base.@kwdef struct EvoGrow <: AbstractStructureSearch
    pop_size::Int = 20
    n_levels::Int = 5
    children_per_parent::Int = 2
    max_terms_per_eq::Int = 5
    λ::Float64 = 1e-3
end

mutable struct Individual
    structure::StructureSpec
    params::Vector{Float64}
    loss::Float64
    objective::Float64
end

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

"""
    _allowed_terms(basis::StagedPolynomialBasis, stage::Int)

Return all basis term indices that are unlocked up to and including `stage`.
"""
function _allowed_terms(basis::StagedPolynomialBasis, stage::Int)
    return vcat(basis.term_groups[1:stage]...)
end

"""
    _current_stage_terms(basis::StagedPolynomialBasis, stage::Int)

Return only the term indices introduced in the current stage.
"""
function _current_stage_terms(basis::StagedPolynomialBasis, stage::Int)
    return basis.term_groups[stage]
end

"""
    _max_stage(basis::StagedPolynomialBasis)

Number of stages in the staged basis.
"""
_max_stage(basis::StagedPolynomialBasis) = length(basis.term_groups)

"""
Fallback for non-staged bases: all terms are available immediately.
This keeps EvoGrow v1-compatible.
"""
function _allowed_terms(basis::AbstractBasis, stage::Int)
    return collect(1:basis_num_terms(basis))
end

function _current_stage_terms(basis::AbstractBasis, stage::Int)
    return collect(1:basis_num_terms(basis))
end

_max_stage(basis::AbstractBasis) = 1

"""
    _allowed_term_names(basis, allowed_terms)

Pretty names for currently unlocked basis terms.
"""
function _allowed_term_names(basis::AbstractBasis, allowed_terms::Vector{Int})
    return [basis_term_name(basis, i) for i in allowed_terms]
end

# ------------------------------------------------------------
# Initialization
# ------------------------------------------------------------

function _init_population(strategy::EvoGrow, dim::Int, allowed_terms::Vector{Int})
    pop = Individual[]
    for _ in 1:strategy.pop_size
        active = Vector{Vector{Int}}(undef, dim)
        for k in 1:dim
            active[k] = [rand(allowed_terms)]
        end
        push!(pop, Individual(StructureSpec(active), Float64[], Inf, Inf))
    end
    return pop
end

# ------------------------------------------------------------
# Expansion
# ------------------------------------------------------------

"""
    _expand(ind, dim, allowed_terms; ...)

Standard growth:
- add one random allowed term to one random equation
"""
function _expand(ind::Individual,
                 dim::Int,
                 allowed_terms::Vector{Int};
                 n_children::Int,
                 max_terms_per_eq::Int)

    children = Individual[]

    for _ in 1:n_children
        new_idxs = [copy(v) for v in ind.structure.active_idxs]
        k = rand(1:dim)

        existing = new_idxs[k]
        candidates = setdiff(allowed_terms, existing)

        if !isempty(candidates) && length(existing) < max_terms_per_eq
            push!(new_idxs[k], rand(candidates))
            new_idxs[k] = sort!(unique(new_idxs[k]))
        end

        push!(children, Individual(StructureSpec(new_idxs), Float64[], Inf, Inf))
    end

    return children
end

"""
    _expand_stage_aware(ind, dim, allowed_terms, new_stage_terms; ...)

Stage-aware growth:
- tries to add at least one term from `new_stage_terms`
- if impossible, falls back to standard allowed-term expansion
"""
function _expand_stage_aware(ind::Individual,
                             dim::Int,
                             allowed_terms::Vector{Int},
                             new_stage_terms::Vector{Int};
                             n_children::Int,
                             max_terms_per_eq::Int)

    children = Individual[]

    for _ in 1:n_children
        new_idxs = [copy(v) for v in ind.structure.active_idxs]

        # equations that can still grow
        growable_eqs = [k for k in 1:dim if length(new_idxs[k]) < max_terms_per_eq]

        if isempty(growable_eqs)
            push!(children, Individual(StructureSpec(new_idxs), Float64[], Inf, Inf))
            continue
        end

        # prefer equations where a truly new stage-term is still available
        eqs_with_new_terms = Int[]
        for k in growable_eqs
            existing = new_idxs[k]
            candidates_new = setdiff(new_stage_terms, existing)
            if !isempty(candidates_new)
                push!(eqs_with_new_terms, k)
            end
        end

        if !isempty(eqs_with_new_terms)
            k = rand(eqs_with_new_terms)
            existing = new_idxs[k]
            candidates_new = setdiff(new_stage_terms, existing)

            push!(new_idxs[k], rand(candidates_new))
            new_idxs[k] = sort!(unique(new_idxs[k]))
        else
            # fallback: standard expansion over all allowed terms
            k = rand(growable_eqs)
            existing = new_idxs[k]
            candidates = setdiff(allowed_terms, existing)

            if !isempty(candidates)
                push!(new_idxs[k], rand(candidates))
                new_idxs[k] = sort!(unique(new_idxs[k]))
            end
        end

        push!(children, Individual(StructureSpec(new_idxs), Float64[], Inf, Inf))
    end

    return children
end

# ------------------------------------------------------------
# Evaluation
# ------------------------------------------------------------

function _evaluate!(ind::Individual,
                    traj::Trajectory,
                    basis::AbstractBasis,
                    loss::AbstractLoss,
                    optimizer::AbstractOptimizer,
                    λ::Float64,
                    options::DiscoveryOptions)

    f!, n_params, _ = build_rhs(ind.structure, basis)
    params, lval, _ = fit_parameters(optimizer, f!, traj, n_params, loss, options)

    ind.params = params
    ind.loss = lval
    ind.objective = lval + λ * length(params)
    return ind
end

# ------------------------------------------------------------
# Main loop
# ------------------------------------------------------------

"""
    search_structure(strategy::EvoGrow, traj, basis, loss, optimizer, options)

Incremental evolutionary growth.

v2/v2.1 behavior:
- if `basis` is staged, only terms up to `current_stage` are allowed
- on plateau, the next stage is unlocked
- once a new stage is unlocked, child generation becomes stage-aware:
  newly generated children preferentially include at least one term from the
  currently unlocked stage
- on sufficiently low loss, the search stops
- current best population is preserved when stage increases

Returns:
- `structure`: best found `StructureSpec`
- `params`: best fitted parameters
- `loss`: best loss
- `objective`: best objective
- `meta`: diagnostics and pretty-print string
"""
function search_structure(strategy::EvoGrow,
                          traj::Trajectory,
                          basis::AbstractBasis,
                          loss::AbstractLoss,
                          optimizer::AbstractOptimizer,
                          options::DiscoveryOptions)

    dim = size(traj.x, 2)

    current_stage = 1
    max_stage = _max_stage(basis)

    allowed_terms = _allowed_terms(basis, current_stage)
    pop = _init_population(strategy, dim, allowed_terms)

    best_J_hist = Float64[]

    # Respect both strategy cap and global cap
    n_steps = min(strategy.n_levels, options.max_levels)

    for level in 1:n_steps
        options.verbose >= 1 && println("\nLevel $level (stage $current_stage)")

        # refresh allowed terms for current stage
        allowed_terms = _allowed_terms(basis, current_stage)
        current_stage_terms = _current_stage_terms(basis, current_stage)
        allowed_names = _allowed_term_names(basis, allowed_terms)
        current_stage_names = _allowed_term_names(basis, current_stage_terms)

        # -----------------------------------
        # Evaluate current population lazily
        # -----------------------------------
        if options.verbose >= 2
            println("  Evaluating parents...")
        end

        n_parents = length(pop)
        for (i, ind) in enumerate(pop)
            if !isfinite(ind.objective)
                if options.verbose >= 2
                    println("    parent $i / $n_parents")
                end
                _evaluate!(ind, traj, basis, loss, optimizer, strategy.λ, options)

                if options.verbose >= 3
                    println("      structure: ", replace(structure_with_params_string(ind.structure, basis, ind.params), '\n' => ' '))
                    println("      loss: ", ind.loss, " | objective: ", ind.objective)
                end
            else
                if options.verbose >= 3
                    println("    parent $i / $n_parents already evaluated")
                    println("      structure: ", replace(structure_with_params_string(ind.structure, basis, ind.params), '\n' => ' '))
                    println("      loss: ", ind.loss, " | objective: ", ind.objective)
                end
            end
        end

        # -----------------------------------
        # Generate children
        # -----------------------------------
        if options.verbose >= 2
            println("  Generating children...")
            println("  Allowed terms in stage $current_stage: ", allowed_names)
            println("  New terms in current stage: ", current_stage_names)
        end

        children = Individual[]

        if current_stage == 1
            # normal growth in the initial stage
            for ind in pop
                append!(children,
                        _expand(ind, dim, allowed_terms;
                                n_children = strategy.children_per_parent,
                                max_terms_per_eq = strategy.max_terms_per_eq))
            end
        else
            # once a new stage is open, force children to use it when possible
            for ind in pop
                append!(children,
                        _expand_stage_aware(ind, dim, allowed_terms, current_stage_terms;
                                            n_children = strategy.children_per_parent,
                                            max_terms_per_eq = strategy.max_terms_per_eq))
            end
        end

        if options.verbose >= 2
            println("  Generated $(length(children)) children.")
        end

        # -----------------------------------
        # Evaluate children
        # -----------------------------------
        if options.verbose >= 2
            println("  Evaluating children...")
        end

        n_children = length(children)
        for (i, child) in enumerate(children)
            if options.verbose >= 2
                println("    child $i / $n_children")
            end

            _evaluate!(child, traj, basis, loss, optimizer, strategy.λ, options)

            if options.verbose >= 3
                println("      structure: ", replace(structure_with_params_string(child.structure, basis, child.params), '\n' => ' '))
                println("      loss: ", child.loss, " | objective: ", child.objective)
            end
        end

        # -----------------------------------
        # Selection
        # -----------------------------------
        if options.verbose >= 2
            println("  Selecting best survivors...")
        end

        all_inds = vcat(pop, children)
        sort!(all_inds, by = x -> x.objective)
        pop = all_inds[1:strategy.pop_size]

        best = pop[1]
        push!(best_J_hist, best.objective)

        # -----------------------------------
        # Logging
        # -----------------------------------
        if options.verbose >= 1
            println("  Best J: ", best.objective,
                    " | loss=", best.loss,
                    " | n_params=", length(best.params))
        end

        if options.verbose >= 2
            println("  Best structure:")
            println(replace(structure_with_params_string(best.structure, basis, best.params), '\n' => ' '))
        end

        if options.verbose >= 3
            println("  Population snapshot (top 5):")
            for (i, ind) in enumerate(pop[1:min(5, length(pop))])
                println("    #$i  J=$(ind.objective)  loss=$(ind.loss)  n_params=$(length(ind.params))")
                println("       ", replace(structure_with_params_string(ind.structure, basis, ind.params), '\n' => ' '))
            end
        end

        # -----------------------------------
        # Shared stopping / stage progression
        # -----------------------------------
        stop, reason = should_stop(best_J_hist, best.loss, level, options)

        if stop
            # good enough -> stop immediately
            if reason == :loss_tol
                if options.verbose >= 1
                    println("  -> stopping at level $level ($reason)")
                end
                break
            end

            # plateau but more stages available -> unlock next stage
            if (reason == :plateau_absolute || reason == :plateau_relative) && current_stage < max_stage
                current_stage += 1

                if options.verbose >= 1
                    println("  -> plateau reached, increasing complexity to stage $current_stage")
                end

                # Keep current population; next round will generate children from larger term set
                continue
            end

            # otherwise stop
            if options.verbose >= 1
                println("  -> stopping at level $level ($reason)")
            end
            break
        end
    end

    best = pop[1]

    return (
        structure = best.structure,
        params = best.params,
        loss = best.loss,
        objective = best.objective,
        meta = (
            best_loss = best.loss,
            best_objective = best.objective,
            best_structure_pretty = structure_with_params_string(best.structure, basis, best.params),
            best_J_hist = best_J_hist,
            final_stage = current_stage
        )
    )
end